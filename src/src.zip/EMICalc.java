
public class EMICalc {
	
	//public void emiCalc()

}
